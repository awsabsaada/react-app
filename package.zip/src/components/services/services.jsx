import React from 'react'
import './services.css'
import {BsCheck2} from 'react-icons/bs'
const services = () => {
  return (
    <section id='services'>
      <h5>What I Offer</h5>
      <h2>Services</h2>
      <div className="container services__container">
        <article className='service'>
          <div className="service__head">
            <h3>UX Design</h3>
          </div>

          <ul className='service__list'>
            <li>
              <BsCheck2 className='service__list-icon'/>
              <p>Seven years of experience in photography, design</p>
            </li>
            <li>
              <BsCheck2 className='service__list-icon'/>
              <p>Photoshop, Adobe Premiere, After Effects</p>
            </li>
            <li>
              <BsCheck2 className='service__list-icon'/>
              <p>Therefore, I can offer you my services </p>
            </li>
            <li>
              <BsCheck2 className='service__list-icon'/>
              <p>create videos</p>
            </li>
            <li>
              <BsCheck2 className='service__list-icon'/>
              <p>edit photos</p>
            </li>
            <li>
              <BsCheck2 className='service__list-icon'/>
              <p>business cards</p>
            </li>
            <li>
              <BsCheck2 className='service__list-icon'/>
              <p>restaurant menus and else..</p>
            </li>
          </ul>
        </article>
        {/*END OF U*/}
        <article className='service'>
          <div className="service__head">
            <h3>Web Development</h3>
          </div>

          <ul className='service__list'>
            <li>
              <BsCheck2 className='service__list-icon'/>
              <p>Create a good website</p>
            </li>
            <li>
              <BsCheck2 className='service__list-icon'/>
              <p>create a nice portfolio with React </p>
            </li>
            <li>
              <BsCheck2 className='service__list-icon'/>
              <p>i can help you with any problem in php code(debug)</p>
            </li>
            <li>
              <BsCheck2 className='service__list-icon'/>
              <p>create a online store</p>
            </li>
          </ul>
        </article>
        {/*END OF webdevelopment*/}
        <article className='service'>
          <div className="service__head">
            <h3>Conteint Creation</h3>
          </div>

          <ul className='service__list'>
            <li>
              <BsCheck2 className='service__list-icon'/>
              <p> Content management website</p>
            </li>
            <li>
              <BsCheck2 className='service__list-icon'/>
              <p> Content management Facebook</p>
            </li>
            <li>
              <BsCheck2 className='service__list-icon'/>
              <p> Content management Instagram</p>
            </li>

          </ul>
        </article>
        {/*END OF U*/}
      </div>
    </section>
  )
}

export default services