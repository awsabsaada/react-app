import React, { useState, useEffect } from "react";
import "./review.css";

const Review = ({ product }) => {
  const [review, setReview] = useState("");
  const [rating, setRating] = useState(0);

  const handleSubmit = (e) => {
    e.preventDefault();

    // Send the review to the server
  };

  useEffect(() => {
    // Get the user's name
    const userName = localStorage.getItem("userame");

    // Set the review form with the user's name
    setReview(userName + "'s Review: " + review);
  }, []);

  return (
    <form onSubmit={handleSubmit} className="review-form">
      <h2>Write a Review</h2>
      <input
        type="text"
        placeholder="Your Review"
        value={review}
        onChange={(e) => setReview(e.target.value)}
      />
      <select
        className="rating"
        onChange={(e) => setRating(e.target.value)}
      >
        <option value="1">1 Star</option>
        <option value="2">2 Stars</option>
        <option value="3">3 Stars</option>
        <option value="4">4 Stars</option>
        <option value="5">5 Stars</option>
      </select>
      <button type="submit">Submit</button>
    </form>
  )
}
export default Review